import java.util.ArrayList;
import java.util.Scanner;
class menutools1 {
    static ArrayList<Student> students = new ArrayList<>();
    static int rollNumberCounter = 1;
    static Scanner scanner=new Scanner(System.in);


        // Check eligibility (FSc percentage >= 50%)
        /*double fscPercentage = (fscMarks / tfsc) * 100;
        if (fscPercentage >= 50) {
            String rollNumber = (rollNumberCounter++) +"/BS/CS/23";
            Student student = new Student(formNumber, name, fatherName, matricMarks, fscMarks, tmatricmarks, tfsc, rollNumber);
            students.add(student);
            System.out.println("Student is eligible for the entry test examination. Form submitted successfully."+ "\n |Your Roll Number| : "+ rollNumber );
            student.isEligible = true;
            System.out.println("-----------------------------------------------------------------------------");
        } else {
            System.out.println("Student is not eligible for admission (intermediate marks are less than 50%).");
            System.out.println("-----------------------------------------------------------------------------");
        }*/
    }



